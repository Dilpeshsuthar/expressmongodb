const express = require('express') //express is a web application framework for node js.
const fileUpload = require('express-fileupload') //require is build in function for node js.
const mongodb = require('mongodb') //database mongod
const fs = require('fs') //fs access physical file system & responsible for Syn/non Sync

const app = express()
const router = express.Router() //corresponse to http method & call back function.
const mongoClient = mongodb.MongoClient
const binary = mongodb.Binary //It is used to read binarydata from mongod.


//Inserted File
function insertFile(file, res) {
    mongoClient.connect('mongodb://localhost:27017', { //Bydeault Mongodb Localhost.
        useNewUrlParser: true //this is used to parse Mongodb connection. 
    }, (error, client) => {
        if (error) {
            return error
        } else {
            let db = client.db('storeDB') //Mongodb Database Name
            let collection = db.collection('files') //Mongodb Collection Name 
            try {
                collection.insertOne(file)
                console.log('File Inserted') //File is inserted
            } catch (error) {
                console.log('Error while inserting:', error)
            }
            client.close()
            res.redirect('/')
        }

    })
}


router.get("/", (req, res) => {
    res.sendFile('./index.html', { //function sends html files to browser
        root: __dirname
    })
})

router.get("/download", (req, res) => { //request get method is used in hhtp server handling. 
    getFiles(res) //get files from browser
})

app.use(fileUpload()) //app.use is called every time a request is sent to a server.

router.post("/upload", (req, res) => { //request post method is used in hhtp server handling.
    let file = {
        name: req.body.name,
        summery: req.body.summery,
        file: binary(req.files.uploadedFile.data)
    }
    insertFile(file, res)
})

//Get the downlord file 
function getFiles(res) {
    mongoClient.connect('mongodb://localhost:27017', { //Bydeault Mongodb Localhost.
        useNewUrlParser: true //this is used to parse Mongodb connection.
    }, (error, client) => {
        if (error) {
            return err
        } else {
            let db = client.db('storeDB') //database
            let collection = db.collection('files') //Collection in databases.
            collection.find({}).toArray((error, doc) => {
                if (error) {
                    console.log('Unable to find the Image:', error)
                } else {
                    let buffer = doc[0].file.buffer
                    fs.writeFileSync('uploadedImage.jpg', buffer)
                }
            })
            client.close()
            res.redirect('/')
        }

    })
}


app.use("/", router)

app.listen(3001, () => console.log('Started on 3001 port'))